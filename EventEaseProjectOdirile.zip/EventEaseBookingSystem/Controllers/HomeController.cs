using EventEaseBooking.Data;
using EventEaseBooking.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventEaseBooking.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        // GET: Home/Search?q=...
        // A single search box that looks across Venues, Events and Bookings at once.
        public async Task<IActionResult> Search(string? q)
        {
            var result = new GlobalSearchResult { Query = q };

            if (!string.IsNullOrWhiteSpace(q))
            {
                result.Venues = await _context.Venues
                    .Where(v => v.VenueName.Contains(q) || v.Location.Contains(q))
                    .ToListAsync();

                result.Events = await _context.Events
                    .Include(e => e.Venue)
                    .Where(e => e.EventName.Contains(q) ||
                                (e.Description != null && e.Description.Contains(q)))
                    .ToListAsync();

                result.Bookings = await _context.Bookings
                    .Include(b => b.Event)
                    .Include(b => b.Venue)
                    .Where(b => (b.Event != null && b.Event.EventName.Contains(q)) ||
                                (b.Venue != null && b.Venue.VenueName.Contains(q)))
                    .ToListAsync();
            }

            return View(result);
        }

        public IActionResult Error()
        {
            return View();
        }
    }

    public class GlobalSearchResult
    {
        public string? Query { get; set; }
        public List<Venue> Venues { get; set; } = new();
        public List<Event> Events { get; set; } = new();
        public List<Booking> Bookings { get; set; } = new();
    }
}
