using EventEaseBooking.Data;
using EventEaseBooking.Models;
using EventEaseBooking.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventEaseBooking.Controllers
{
    public class VenuesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IBlobStorageService _blobStorageService;

        public VenuesController(ApplicationDbContext context, IBlobStorageService blobStorageService)
        {
            _context = context;
            _blobStorageService = blobStorageService;
        }

        // GET: Venues
        // Supports search/filter by name, location, or minimum capacity
        public async Task<IActionResult> Index(string? searchString, int? minCapacity)
        {
            var venues = from v in _context.Venues select v;

            if (!string.IsNullOrEmpty(searchString))
            {
                venues = venues.Where(v =>
                    v.VenueName.Contains(searchString) ||
                    v.Location.Contains(searchString));
            }

            if (minCapacity.HasValue)
            {
                venues = venues.Where(v => v.Capacity >= minCapacity.Value);
            }

            ViewData["CurrentFilter"] = searchString;
            ViewData["CurrentMinCapacity"] = minCapacity;
            return View(await venues.OrderBy(v => v.VenueName).ToListAsync());
        }

        // GET: Venues/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var venue = await _context.Venues
                .Include(v => v.Bookings)!.ThenInclude(b => b.Event)
                .FirstOrDefaultAsync(v => v.VenueId == id);
            if (venue == null) return NotFound();

            return View(venue);
        }

        // GET: Venues/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Venues/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("VenueName,Location,Capacity")] Venue venue, IFormFile? imageFile)
        {
            if (imageFile != null && imageFile.Length > 0)
            {
                try
                {
                    venue.ImageUrl = await _blobStorageService.UploadImageAsync(imageFile);
                }
                catch (ArgumentException ex)
                {
                    ModelState.AddModelError(nameof(imageFile), ex.Message);
                }
            }

            if (ModelState.IsValid)
            {
                _context.Add(venue);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Venue created successfully.";
                return RedirectToAction(nameof(Index));
            }
            return View(venue);
        }

        // GET: Venues/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var venue = await _context.Venues.FindAsync(id);
            if (venue == null) return NotFound();

            return View(venue);
        }

        // POST: Venues/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("VenueId,VenueName,Location,Capacity,ImageUrl")] Venue venue, IFormFile? imageFile)
        {
            if (id != venue.VenueId) return NotFound();

            if (imageFile != null && imageFile.Length > 0)
            {
                try
                {
                    var oldImageUrl = venue.ImageUrl;
                    venue.ImageUrl = await _blobStorageService.UploadImageAsync(imageFile);
                    await _blobStorageService.DeleteImageAsync(oldImageUrl);
                }
                catch (ArgumentException ex)
                {
                    ModelState.AddModelError(nameof(imageFile), ex.Message);
                }
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(venue);
                    await _context.SaveChangesAsync();
                    TempData["Success"] = "Venue updated successfully.";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!VenueExists(venue.VenueId)) return NotFound();
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(venue);
        }

        // GET: Venues/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var venue = await _context.Venues.FirstOrDefaultAsync(v => v.VenueId == id);
            if (venue == null) return NotFound();

            // Warn the booking specialist up front if this venue has active bookings
            var activeBookingCount = await _context.Bookings.CountAsync(b => b.VenueId == id);
            ViewData["ActiveBookingCount"] = activeBookingCount;

            return View(venue);
        }

        // POST: Venues/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var venue = await _context.Venues.FindAsync(id);
            if (venue != null)
            {
                bool hasBookings = await _context.Bookings.AnyAsync(b => b.VenueId == id);
                if (hasBookings)
                {
                    TempData["Error"] = $"'{venue.VenueName}' cannot be deleted because it has existing bookings. Cancel those bookings first.";
                    return RedirectToAction(nameof(Index));
                }

                await _blobStorageService.DeleteImageAsync(venue.ImageUrl);
                _context.Venues.Remove(venue);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Venue deleted successfully.";
            }
            return RedirectToAction(nameof(Index));
        }

        // GET: Venues/Availability
        // Advanced filter: which venues are free (or booked) across a given date range,
        // optionally narrowed by event type of what's already booked there.
        public async Task<IActionResult> Availability(DateTime? fromDate, DateTime? toDate, int? minCapacity)
        {
            fromDate ??= DateTime.Today;
            toDate ??= DateTime.Today;

            var venues = await _context.Venues
                .Include(v => v.Bookings)
                .Where(v => !minCapacity.HasValue || v.Capacity >= minCapacity.Value)
                .OrderBy(v => v.VenueName)
                .ToListAsync();

            var results = venues.Select(v => new VenueAvailability
            {
                Venue = v,
                IsAvailable = !(v.Bookings ?? new List<Booking>())
                    .Any(b => b.BookingDate.Date >= fromDate.Value.Date && b.BookingDate.Date <= toDate.Value.Date)
            }).ToList();

            ViewData["FromDate"] = fromDate.Value.ToString("yyyy-MM-dd");
            ViewData["ToDate"] = toDate.Value.ToString("yyyy-MM-dd");
            ViewData["MinCapacity"] = minCapacity;

            return View(results);
        }

        private bool VenueExists(int id)
        {
            return _context.Venues.Any(e => e.VenueId == id);
        }
    }

    public class VenueAvailability
    {
        public Venue Venue { get; set; } = null!;
        public bool IsAvailable { get; set; }
    }
}
