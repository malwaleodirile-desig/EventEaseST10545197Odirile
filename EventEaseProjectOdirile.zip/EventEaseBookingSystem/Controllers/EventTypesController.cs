using EventEaseBooking.Data;
using EventEaseBooking.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventEaseBooking.Controllers
{
    public class EventTypesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EventTypesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: EventTypes
        public async Task<IActionResult> Index()
        {
            return View(await _context.EventTypes.OrderBy(t => t.Name).ToListAsync());
        }

        // GET: EventTypes/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: EventTypes/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Name")] EventType eventType)
        {
            if (ModelState.IsValid)
            {
                _context.Add(eventType);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Event type added.";
                return RedirectToAction(nameof(Index));
            }
            return View(eventType);
        }

        // GET: EventTypes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();
            var eventType = await _context.EventTypes.FindAsync(id);
            if (eventType == null) return NotFound();
            return View(eventType);
        }

        // POST: EventTypes/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("EventTypeId,Name")] EventType eventType)
        {
            if (id != eventType.EventTypeId) return NotFound();

            if (ModelState.IsValid)
            {
                _context.Update(eventType);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Event type updated.";
                return RedirectToAction(nameof(Index));
            }
            return View(eventType);
        }

        // GET: EventTypes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();
            var eventType = await _context.EventTypes.FirstOrDefaultAsync(t => t.EventTypeId == id);
            if (eventType == null) return NotFound();

            ViewData["UsageCount"] = await _context.Events.CountAsync(e => e.EventTypeId == id);
            return View(eventType);
        }

        // POST: EventTypes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var eventType = await _context.EventTypes.FindAsync(id);
            if (eventType != null)
            {
                bool inUse = await _context.Events.AnyAsync(e => e.EventTypeId == id);
                if (inUse)
                {
                    TempData["Error"] = $"'{eventType.Name}' cannot be deleted because events are classified under it.";
                    return RedirectToAction(nameof(Index));
                }

                _context.EventTypes.Remove(eventType);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Event type deleted.";
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
