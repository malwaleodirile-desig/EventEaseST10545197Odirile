using EventEaseBooking.Data;
using EventEaseBooking.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace EventEaseBooking.Controllers
{
    public class BookingsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Bookings
        // Advanced filtering: venue, event type, date range, and free-text search across event/venue name
        public async Task<IActionResult> Index(
            int? venueId,
            int? eventTypeId,
            DateTime? fromDate,
            DateTime? toDate,
            string? searchString)
        {
            var bookings = _context.Bookings
                .Include(b => b.Event)!.ThenInclude(e => e!.EventType)
                .Include(b => b.Venue)
                .AsQueryable();

            if (venueId.HasValue)
            {
                bookings = bookings.Where(b => b.VenueId == venueId);
            }

            if (eventTypeId.HasValue)
            {
                bookings = bookings.Where(b => b.Event != null && b.Event.EventTypeId == eventTypeId);
            }

            if (fromDate.HasValue)
            {
                bookings = bookings.Where(b => b.BookingDate.Date >= fromDate.Value.Date);
            }

            if (toDate.HasValue)
            {
                bookings = bookings.Where(b => b.BookingDate.Date <= toDate.Value.Date);
            }

            if (!string.IsNullOrEmpty(searchString))
            {
                bookings = bookings.Where(b =>
                    (b.Event != null && b.Event.EventName.Contains(searchString)) ||
                    (b.Venue != null && b.Venue.VenueName.Contains(searchString)));
            }

            ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName", venueId);
            ViewData["EventTypeId"] = new SelectList(_context.EventTypes, "EventTypeId", "Name", eventTypeId);
            ViewData["FromDate"] = fromDate?.ToString("yyyy-MM-dd");
            ViewData["ToDate"] = toDate?.ToString("yyyy-MM-dd");
            ViewData["CurrentFilter"] = searchString;

            return View(await bookings.OrderBy(b => b.BookingDate).ToListAsync());
        }

        // GET: Bookings/Schedule
        // A consolidated, at-a-glance view of all bookings grouped by date
        public async Task<IActionResult> Schedule()
        {
            var bookings = await _context.Bookings
                .Include(b => b.Event)!.ThenInclude(e => e!.EventType)
                .Include(b => b.Venue)
                .OrderBy(b => b.BookingDate)
                .ToListAsync();

            var grouped = bookings
                .GroupBy(b => b.BookingDate.Date)
                .OrderBy(g => g.Key)
                .ToList();

            return View(grouped);
        }

        // GET: Bookings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings
                .Include(b => b.Event)!.ThenInclude(e => e!.EventType)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(b => b.BookingId == id);
            if (booking == null) return NotFound();

            return View(booking);
        }

        // GET: Bookings/Create
        public IActionResult Create()
        {
            ViewData["EventId"] = new SelectList(_context.Events, "EventId", "EventName");
            ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName");
            return View();
        }

        // POST: Bookings/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EventId,VenueId,BookingDate")] Booking booking)
        {
            // Prevent double-booking: same venue, same date, already booked
            bool conflict = await _context.Bookings.AnyAsync(b =>
                b.VenueId == booking.VenueId &&
                b.BookingDate.Date == booking.BookingDate.Date);

            if (conflict)
            {
                ModelState.AddModelError(string.Empty,
                    "This venue is already booked on the selected date. Please choose a different date or venue.");
            }

            if (ModelState.IsValid)
            {
                _context.Add(booking);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Booking created successfully.";
                return RedirectToAction(nameof(Index));
            }

            ViewData["EventId"] = new SelectList(_context.Events, "EventId", "EventName", booking.EventId);
            ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName", booking.VenueId);
            return View(booking);
        }

        // GET: Bookings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings.FindAsync(id);
            if (booking == null) return NotFound();

            ViewData["EventId"] = new SelectList(_context.Events, "EventId", "EventName", booking.EventId);
            ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName", booking.VenueId);
            return View(booking);
        }

        // POST: Bookings/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookingId,EventId,VenueId,BookingDate")] Booking booking)
        {
            if (id != booking.BookingId) return NotFound();

            bool conflict = await _context.Bookings.AnyAsync(b =>
                b.VenueId == booking.VenueId &&
                b.BookingDate.Date == booking.BookingDate.Date &&
                b.BookingId != booking.BookingId);

            if (conflict)
            {
                ModelState.AddModelError(string.Empty,
                    "This venue is already booked on the selected date. Please choose a different date or venue.");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(booking);
                    await _context.SaveChangesAsync();
                    TempData["Success"] = "Booking updated successfully.";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookingExists(booking.BookingId)) return NotFound();
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }

            ViewData["EventId"] = new SelectList(_context.Events, "EventId", "EventName", booking.EventId);
            ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName", booking.VenueId);
            return View(booking);
        }

        // GET: Bookings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings
                .Include(b => b.Event)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(b => b.BookingId == id);
            if (booking == null) return NotFound();

            return View(booking);
        }

        // POST: Bookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking != null)
            {
                _context.Bookings.Remove(booking);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Booking cancelled successfully.";
            }
            return RedirectToAction(nameof(Index));
        }

        private bool BookingExists(int id)
        {
            return _context.Bookings.Any(e => e.BookingId == id);
        }
    }
}
