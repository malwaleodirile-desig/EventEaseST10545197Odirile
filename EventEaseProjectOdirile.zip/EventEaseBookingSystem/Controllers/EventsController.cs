using EventEaseBooking.Data;
using EventEaseBooking.Models;
using EventEaseBooking.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace EventEaseBooking.Controllers
{
    public class EventsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IBlobStorageService _blobStorageService;

        public EventsController(ApplicationDbContext context, IBlobStorageService blobStorageService)
        {
            _context = context;
            _blobStorageService = blobStorageService;
        }

        // GET: Events
        // Supports search by name/venue and filtering by event type
        public async Task<IActionResult> Index(string? searchString, int? eventTypeId)
        {
            var events = _context.Events
                .Include(e => e.Venue)
                .Include(e => e.EventType)
                .AsQueryable();

            if (!string.IsNullOrEmpty(searchString))
            {
                events = events.Where(e =>
                    e.EventName.Contains(searchString) ||
                    (e.Venue != null && e.Venue.VenueName.Contains(searchString)));
            }

            if (eventTypeId.HasValue)
            {
                events = events.Where(e => e.EventTypeId == eventTypeId);
            }

            ViewData["CurrentFilter"] = searchString;
            ViewData["EventTypeId"] = new SelectList(_context.EventTypes, "EventTypeId", "Name", eventTypeId);
            return View(await events.OrderBy(e => e.EventDate).ToListAsync());
        }

        // GET: Events/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var evt = await _context.Events
                .Include(e => e.Venue)
                .Include(e => e.EventType)
                .FirstOrDefaultAsync(e => e.EventId == id);
            if (evt == null) return NotFound();

            return View(evt);
        }

        // GET: Events/Create
        public IActionResult Create()
        {
            ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName");
            ViewData["EventTypeId"] = new SelectList(_context.EventTypes, "EventTypeId", "Name");
            return View();
        }

        // POST: Events/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EventName,EventDate,Description,VenueId,EventTypeId")] Event evt, IFormFile? imageFile)
        {
            if (imageFile != null && imageFile.Length > 0)
            {
                try
                {
                    evt.ImageUrl = await _blobStorageService.UploadImageAsync(imageFile);
                }
                catch (ArgumentException ex)
                {
                    ModelState.AddModelError(nameof(imageFile), ex.Message);
                }
            }

            if (ModelState.IsValid)
            {
                _context.Add(evt);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Event created successfully.";
                return RedirectToAction(nameof(Index));
            }
            ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName", evt.VenueId);
            ViewData["EventTypeId"] = new SelectList(_context.EventTypes, "EventTypeId", "Name", evt.EventTypeId);
            return View(evt);
        }

        // GET: Events/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var evt = await _context.Events.FindAsync(id);
            if (evt == null) return NotFound();

            ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName", evt.VenueId);
            ViewData["EventTypeId"] = new SelectList(_context.EventTypes, "EventTypeId", "Name", evt.EventTypeId);
            return View(evt);
        }

        // POST: Events/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("EventId,EventName,EventDate,Description,ImageUrl,VenueId,EventTypeId")] Event evt, IFormFile? imageFile)
        {
            if (id != evt.EventId) return NotFound();

            if (imageFile != null && imageFile.Length > 0)
            {
                try
                {
                    var oldImageUrl = evt.ImageUrl;
                    evt.ImageUrl = await _blobStorageService.UploadImageAsync(imageFile);
                    await _blobStorageService.DeleteImageAsync(oldImageUrl);
                }
                catch (ArgumentException ex)
                {
                    ModelState.AddModelError(nameof(imageFile), ex.Message);
                }
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(evt);
                    await _context.SaveChangesAsync();
                    TempData["Success"] = "Event updated successfully.";
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EventExists(evt.EventId)) return NotFound();
                    throw;
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["VenueId"] = new SelectList(_context.Venues, "VenueId", "VenueName", evt.VenueId);
            ViewData["EventTypeId"] = new SelectList(_context.EventTypes, "EventTypeId", "Name", evt.EventTypeId);
            return View(evt);
        }

        // GET: Events/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var evt = await _context.Events
                .Include(e => e.Venue)
                .Include(e => e.EventType)
                .FirstOrDefaultAsync(e => e.EventId == id);
            if (evt == null) return NotFound();

            var activeBookingCount = await _context.Bookings.CountAsync(b => b.EventId == id);
            ViewData["ActiveBookingCount"] = activeBookingCount;

            return View(evt);
        }

        // POST: Events/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var evt = await _context.Events.FindAsync(id);
            if (evt != null)
            {
                bool hasBookings = await _context.Bookings.AnyAsync(b => b.EventId == id);
                if (hasBookings)
                {
                    TempData["Error"] = $"'{evt.EventName}' cannot be deleted because it has existing bookings. Cancel those bookings first.";
                    return RedirectToAction(nameof(Index));
                }

                await _blobStorageService.DeleteImageAsync(evt.ImageUrl);
                _context.Events.Remove(evt);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Event deleted successfully.";
            }
            return RedirectToAction(nameof(Index));
        }

        private bool EventExists(int id)
        {
            return _context.Events.Any(e => e.EventId == id);
        }
    }
}
