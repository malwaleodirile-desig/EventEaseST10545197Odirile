using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace EventEaseBooking.Services
{
    public class BlobStorageService : IBlobStorageService
    {
        private readonly string _connectionString;
        private readonly string _containerName;
        private readonly ILogger<BlobStorageService> _logger;

        private static readonly string[] AllowedExtensions = { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
        private const long MaxFileSizeBytes = 5 * 1024 * 1024; // 5 MB

        public BlobStorageService(IConfiguration configuration, ILogger<BlobStorageService> logger)
        {
            _connectionString = configuration["AzureBlobStorage:ConnectionString"]
                ?? throw new InvalidOperationException("AzureBlobStorage:ConnectionString is not configured.");
            _containerName = configuration["AzureBlobStorage:ContainerName"] ?? "venue-event-images";
            _logger = logger;
        }

        public async Task<string> UploadImageAsync(IFormFile file)
        {
            if (file == null || file.Length == 0)
                throw new ArgumentException("No file was provided.");

            var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (!AllowedExtensions.Contains(extension))
                throw new ArgumentException("Only image files (jpg, jpeg, png, gif, webp) are allowed.");

            if (file.Length > MaxFileSizeBytes)
                throw new ArgumentException("The image must be smaller than 5 MB.");

            var containerClient = new BlobContainerClient(_connectionString, _containerName);
            await containerClient.CreateIfNotExistsAsync(PublicAccessType.Blob);

            var blobName = $"{Guid.NewGuid()}{extension}";
            var blobClient = containerClient.GetBlobClient(blobName);

            using (var stream = file.OpenReadStream())
            {
                await blobClient.UploadAsync(stream, new BlobHttpHeaders { ContentType = file.ContentType });
            }

            _logger.LogInformation("Uploaded image {BlobName} to container {Container}", blobName, _containerName);

            return blobClient.Uri.ToString();
        }

        public async Task DeleteImageAsync(string? blobUrl)
        {
            if (string.IsNullOrWhiteSpace(blobUrl)) return;
            if (!blobUrl.Contains(".blob.core.windows.net")) return; // not a blob URL (e.g. old placeholder link) - skip

            try
            {
                var containerClient = new BlobContainerClient(_connectionString, _containerName);
                var blobName = Path.GetFileName(new Uri(blobUrl).LocalPath);
                await containerClient.DeleteBlobIfExistsAsync(blobName);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to delete blob for URL {BlobUrl}", blobUrl);
            }
        }
    }
}
