namespace EventEaseBooking.Services
{
    public interface IBlobStorageService
    {
        /// <summary>
        /// Uploads a file to Azure Blob Storage and returns the public URL of the uploaded blob.
        /// </summary>
        Task<string> UploadImageAsync(IFormFile file);

        /// <summary>
        /// Deletes a blob given its full URL. Safe to call with a null/empty/non-blob URL (no-op).
        /// </summary>
        Task DeleteImageAsync(string? blobUrl);
    }
}
