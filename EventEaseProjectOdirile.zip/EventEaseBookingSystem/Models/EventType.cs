using System.ComponentModel.DataAnnotations;

namespace EventEaseBooking.Models
{
    public class EventType
    {
        public int EventTypeId { get; set; }

        [Required(ErrorMessage = "Event type name is required.")]
        [StringLength(50)]
        [Display(Name = "Event Type")]
        public string Name { get; set; } = string.Empty;

        // Navigation property
        public ICollection<Event>? Events { get; set; }
    }
}
